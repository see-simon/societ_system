<!DOCTYPE html>
<?php
include("session.php");
include("connection.php");
include("funtions.php");

$error = "";
   if(isset($_POST['reset']))
   {
        $email= mysqli_real_escape_string($con,$_POST['email']);
        $error = "";

        $subject = "Email Reset";

        $body = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        </head>
        <body>
       
        <div>
               
               
                <p>Please click the following link to reset your password:  "<a href ="http://localhost//Society_Management_System/reset.php?email='.urlencode($email).'"  target="_blank">Password Reset</a>"</p>
                <p> </p>
                <p> </p>
                <p>Regards </p>
                <p> Admin </p>
       
       
        </div>
        </body>
        </html>';
        

        $sql= "SELECT * FROM user WHERE email = '$email'  ";

        $res = mysqli_query($con,$sql);

        $rows = mysqli_num_rows($res);

        if($rows == 1)
        {
            mysqli_query($con,"INSERT INTO `temporary`(`name`) VALUES('$email')"); 
            if(sendMail($email,$subject,$body))
            {
                $error = "Link has been submitted to your email";
            }
       
        }
        else {
            $error = "Sorry we could not find your email,<br> please check if you submitted the correct one";
        }

        
   }

?>

<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Society Management System</title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
        <style>
    body {
      background-image: url(2.jpg) 
    }
  </style>

    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">Password Recovery</h3></div>
                                    <div class="card-body">
                                        <div class="small mb-3 text-muted">Enter your email address and we will send you a link to reset your password.</div>
                                        <div> <label class="text-center font-weight-bold my-4" style="color:red;"><?php echo $error; ?></label> </div>
                                        <form  action="password.php" method="post">
                                            <div class="form-group">
                                                <label class="small mb-1" for="inputEmailAddress">Email</label>
                                                <input class="form-control py-4" name="email" id="inputEmailAddress" type="email" aria-describedby="emailHelp" placeholder="Enter email address" />
                                            </div>
                                            <div class="form-group d-flex align-items-center justify-content-between mt-4 mb-0">
                                                <a class="small" href="index.php">Return to login</a>
                                                <button class="btn btn-primary" href="#" type="submit" name="reset">Reset Password</button>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="card-footer text-center">
                                        <div class="small"><a href="register.php">Need an account? Sign up!</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
            <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; Society Management System</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
