paypal.Buttons({
	style:{
		color:'blue',
		shape:'pill'
	}
}).render('#pay');