

This are the things you need to follow:

As ussual make chaneg son connection.php,bootstrap.php and functions.php

User can pay with all availaible payment method.

User can pay for outstanding fess just like Admin

Whenyou present There is a minor problem on outstanding for Admin 

Play around with it if you select the use to pay for it will give you only one user instead of the correct one so you mustknow the user it displays and click on it when you pay outstang.

Functopns of a system or flow:

member registers on a system
Admin can't register another admin can register him.

When Mwmber Loged in :

It take them to a payments they can viw payments.

Mwmber can view all payments,outstanding,anully

Memmber can pay using INSTANT PAYMENT,Cash, or CREDIT with money reserved durring cash payment.

Mwmber apply for claim  and wait for approval

Once approve the Mwmber is InActive so he/ she can no longer access the system

Admin 

Takes him/her to admin page .

Admin can:
can view all payments,per user ,outstanding
can view user infomation

can pay for User with CREDIT,CASH,INSTANT PAYMENT
can add user and admin

Admin can view claim application and aprrove based on the reasons 

if claimis rejected user is activated.

on outstanding it it doesn show new users 

Non Functional

Both User and admin view and add events
Both can use notification


Explain to the the claim reseaon


Make sure you don't pt your self in a conner .

resaon user is activated it is because he/she is dead so they won't use a system


Credit make sure reserve table is empty when you present.
It has the same issue as outstanding.